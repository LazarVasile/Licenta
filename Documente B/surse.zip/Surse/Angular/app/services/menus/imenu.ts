import { IProduct } from '../products/products';

export interface IMenu {
    buy: number,
    total : number,
}
