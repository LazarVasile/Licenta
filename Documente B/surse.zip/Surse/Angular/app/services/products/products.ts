export interface IProduct{
    name : string,
    category : string,
    professor_price : number,
    student_price : number,
    weight : number,
    description : string
}