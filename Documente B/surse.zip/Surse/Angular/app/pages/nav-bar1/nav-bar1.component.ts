import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-bar1',
  templateUrl: './nav-bar1.component.html',
  styleUrls: ['./nav-bar1.component.css']
})
export class NavBar1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
