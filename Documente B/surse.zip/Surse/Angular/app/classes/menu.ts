export class Menu {
    total : number;
    buy : number;

    constructor(total : number, buy : number){
        this.total = total;
        this.buy = buy;
    }
}
